﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace АненствоНедвижемости
{
    public partial class ВходСистема : Form
    {
        public ВходСистема()
        {
            InitializeComponent();
        }

        private void bEnter_Click(object sender, EventArgs e)
        {
            using (var db = new Demo_DataBaseEntities())
            {
                var ex = db.User.FirstOrDefault(item => item.Логин == loginbox.Text && item.Пароль == passbox.Text);
                if (ex = 0)
                {
                    var n = db.User.FirstOrDefault(item => item.Логин == loginbox.Text);
                    MessageBox.Show("Неверный логин или пароль");
                }
                else
                {
                    var y = db.User.FirstOrDefault(item => item.Логин == loginbox.Text);
                    Form menu = new Меню();
                    menu.Show();
                    this.Hide();
                }
            }
        }
    }
}
