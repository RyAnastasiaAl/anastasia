﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace АненствоНедвижемости
{
    public partial class Меню : Form
    {
        public Меню()
        {
            InitializeComponent();
        }

        private void bCreate_Click(object sender, EventArgs e)
        {
            Form create = new СоздатьКлиента();
            create.Show();
            this.Hide();
        }

        private void bTable_Click(object sender, EventArgs e)
        {
            Form tabl = new СписокКлиентов();
            tabl.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form ex = new ВходСистема();
            ex.Show();
            this.Hide();
        }
    }
}
