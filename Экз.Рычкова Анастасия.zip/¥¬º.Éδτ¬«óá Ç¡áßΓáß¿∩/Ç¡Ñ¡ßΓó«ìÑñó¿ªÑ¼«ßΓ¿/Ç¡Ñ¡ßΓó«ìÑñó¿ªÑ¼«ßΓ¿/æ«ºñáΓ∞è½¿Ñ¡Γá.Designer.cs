﻿
namespace АненствоНедвижемости
{
    partial class СоздатьКлиента
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tfname = new System.Windows.Forms.TextBox();
            this.tname = new System.Windows.Forms.TextBox();
            this.toname = new System.Windows.Forms.TextBox();
            this.ttel = new System.Windows.Forms.TextBox();
            this.tadres = new System.Windows.Forms.TextBox();
            this.bSave = new System.Windows.Forms.Button();
            this.bMenu = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(77, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Фамилия";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(104, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Имя";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(79, 95);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Отчество";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(40, 122);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Номер телефона";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(29, 149);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Электронная почта";
            // 
            // tfname
            // 
            this.tfname.Location = new System.Drawing.Point(146, 34);
            this.tfname.Name = "tfname";
            this.tfname.Size = new System.Drawing.Size(145, 20);
            this.tfname.TabIndex = 5;
            // 
            // tname
            // 
            this.tname.Location = new System.Drawing.Point(146, 61);
            this.tname.Name = "tname";
            this.tname.Size = new System.Drawing.Size(145, 20);
            this.tname.TabIndex = 6;
            // 
            // toname
            // 
            this.toname.Location = new System.Drawing.Point(146, 88);
            this.toname.Name = "toname";
            this.toname.Size = new System.Drawing.Size(145, 20);
            this.toname.TabIndex = 7;
            // 
            // ttel
            // 
            this.ttel.Location = new System.Drawing.Point(146, 115);
            this.ttel.Name = "ttel";
            this.ttel.Size = new System.Drawing.Size(145, 20);
            this.ttel.TabIndex = 8;
            // 
            // tadres
            // 
            this.tadres.Location = new System.Drawing.Point(146, 142);
            this.tadres.Name = "tadres";
            this.tadres.Size = new System.Drawing.Size(145, 20);
            this.tadres.TabIndex = 9;
            // 
            // bSave
            // 
            this.bSave.Location = new System.Drawing.Point(333, 139);
            this.bSave.Name = "bSave";
            this.bSave.Size = new System.Drawing.Size(75, 23);
            this.bSave.TabIndex = 10;
            this.bSave.Text = "Сохранить";
            this.bSave.UseVisualStyleBackColor = true;
            this.bSave.Click += new System.EventHandler(this.bSave_Click);
            // 
            // bMenu
            // 
            this.bMenu.Location = new System.Drawing.Point(333, 168);
            this.bMenu.Name = "bMenu";
            this.bMenu.Size = new System.Drawing.Size(75, 23);
            this.bMenu.TabIndex = 11;
            this.bMenu.Text = "Меню";
            this.bMenu.UseVisualStyleBackColor = true;
            this.bMenu.Click += new System.EventHandler(this.bMenu_Click);
            // 
            // СоздатьКлиента
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(426, 214);
            this.Controls.Add(this.bMenu);
            this.Controls.Add(this.bSave);
            this.Controls.Add(this.tadres);
            this.Controls.Add(this.ttel);
            this.Controls.Add(this.toname);
            this.Controls.Add(this.tname);
            this.Controls.Add(this.tfname);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "СоздатьКлиента";
            this.Text = "СоздатьКлиента";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tfname;
        private System.Windows.Forms.TextBox tname;
        private System.Windows.Forms.TextBox toname;
        private System.Windows.Forms.TextBox ttel;
        private System.Windows.Forms.TextBox tadres;
        private System.Windows.Forms.Button bSave;
        private System.Windows.Forms.Button bMenu;
    }
}