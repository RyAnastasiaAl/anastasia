﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace АненствоНедвижемости
{
    public partial class СоздатьКлиента : Form
    {
        public СоздатьКлиента()
        {
            InitializeComponent();
        }

        private void bSave_Click(object sender, EventArgs e)
        {
            using (var db = new Demo_DataBaseEntities())
            {
                var name = new Kлиент();
                name.Фамилия = tfname.Text;
                name.Имя = tname.Text;
                name.Отчество = toname.Text;
                name.Телефон = ttel.Text;
                name.Почта = tadres.Text;

                var n = db.Kлиент.FirstOrDefault(item => item.Телефон == ttel.Text);
                if (n == null)

                {
                    db.Kлиент.Add(name);
                    db.SaveChanges();
                    MessageBox.Show("Создан новый пользователь");
                }
                else
                {
                    MessageBox.Show("Пользователь уже существует");
                }
        }   }

        private void bMenu_Click(object sender, EventArgs e)
        {
            Form menu = new Меню();
            menu.Show();
            this.Hide();
        }
    }
}
